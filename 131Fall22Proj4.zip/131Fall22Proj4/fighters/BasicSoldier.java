package fighters;

import framework.BattleField;
import framework.Random131;

public class BasicSoldier {

}
